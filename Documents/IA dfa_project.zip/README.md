# Digital Forensics Agent System (Educational Demo)

This reference implementation demonstrates a *modular, agent-based* digital forensics pipeline with a **SQLite blackboard**, **signature-based discovery**, **SHA-256 hashing**, **metadata extraction (EXIF/PDF)**, **AES-256 ZIP archiving**, and a **simulated transfer** step.

> ⚠️ This project is for coursework demonstration. It is **not** a drop-in replacement for production forensic suites.

---

## Project Tree

```text
forensics_agent/
  blackboard.py
  agents/
    search.py           # magic-number identification
    processing.py       # SHA-256 + EXIF/PDF metadata
    archiving.py        # AES-256 encrypted ZIP via pyzipper
    communication.py    # simulated SFTP transfer
  utils/
    signatures.py       # minimal magic numbers
  tests/
    test_digest_and_pipeline.py
scripts/
  main.py               # CLI pipeline runner
sample_data/
  demo_input/           # tiny test corpus (pdf, jpg, txt)
requirements.txt
README.md
```

## Quickstart

1) Create a virtual environment and install dependencies:
```bash
python -m venv .venv
. .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

2) Run the pipeline on the sample corpus:
```bash
python scripts/main.py sample_data/demo_input --workdir ./work --password secret123
```

You should see a JSON-like dict with paths to the created archive and delivered copy. Inspect `work/blackboard.db` with any SQLite viewer to review logs, files, metadata, and digests.

3) Run tests:
```bash
python -m pytest -q
```

## Evidence Handling Notes

- Discovery uses **magic-number** checks (e.g., `%PDF`, `0xFFD8FF`) to reduce masquerading risk.
- Hashing uses **SHA-256** (`hashlib`) and streams files in chunks (1 MiB by default).
- PDF metadata uses **PyPDF2**; JPEG EXIF uses **exifread** (best-effort; missing tags will be logged but do not fail the pipeline).
- Archives are produced with **AES-256** encryption when a password is provided (`pyzipper`, WZ_AES).
- Transfer is **simulated** by copying the archive to `work/delivered/` and recording a status in the blackboard.

## CLI Options

```bash
python scripts/main.py <INPUT_DIR> --workdir ./work --password <ZIP_PASSWORD>
```

- `INPUT_DIR`: directory to scan (recursively).
- `--workdir`: working directory where the SQLite DB and archives live.
- `--password`: optional password; when set, archives are AES-256 encrypted.

## Design Rationale (brief)

- **Blackboard pattern** to decouple agents (search/processing/archiving/communication).
- **ThreadPoolExecutor** used for I/O-bound hashing/metadata to reduce wall-clock time.
- **SQLite (serverless)**: simple, reproducible, and minimal attack surface for lab contexts.
- **Paramiko/SFTP**: not used in tests to avoid network dependencies; `communication.py` includes a *simulate_transfer* method for deterministic runs.

## Evidence of Execution

- The `sample_data/demo_input` contains a tiny PDF (header-only), a tiny JPEG (header + filler), and a text file (detected as `unknown` by magic number).
- Running the pipeline generates `work/archives/evidence.zip` and a delivered copy in `work/delivered/`.
- The SQLite database (`work/blackboard.db`) records files, metadata, digests, archives, transfers, and logs.

## Academic Integrity

- Inline comments clarify **why** design choices were made (e.g., magic numbers vs. extensions, AES-256 vs. no encryption).
- External libraries are cited in the coursework document; this repository’s `requirements.txt` lists exact versions for reproducibility.

## Known Limitations

- Minimal signature database (extend in `utils/signatures.py`).
- Paramiko/SFTP is not exercised by default; a production environment would integrate authenticated endpoints and proper retry/backoff with checksums.
