import argparse, os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from forensics_agent.blackboard import Blackboard
from forensics_agent.agents.search import SearchAgent
from forensics_agent.agents.processing import ProcessingAgent
from forensics_agent.agents.archiving import ArchivingAgent
from forensics_agent.agents.communication import CommunicationAgent

def process_files(bb: Blackboard, files):
    proc = ProcessingAgent(bb)
    results = []
    with ThreadPoolExecutor(max_workers=os.cpu_count() or 4) as ex:
        futs = []
        for f in files:
            futs.append(ex.submit(_handle_one, proc, f))
        for fut in as_completed(futs):
            results.append(fut.result())
    return results

def _handle_one(proc: ProcessingAgent, path: str):
    digest = proc.generate_sha256(path)
    meta = proc.extract_metadata(path)
    return (path, digest, meta)

def run_pipeline(input_dir: str, workdir: str, password: str = None):
    db = os.path.join(workdir, "blackboard.db")
    out_dir = os.path.join(workdir, "archives")
    deliver_dir = os.path.join(workdir, "delivered")
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(deliver_dir, exist_ok=True)

    bb = Blackboard(db)
    search = SearchAgent(bb)
    arch = ArchivingAgent(bb)
    comm = CommunicationAgent(bb)

    # 1) Discover files
    search.scan_directory(input_dir)
    files = list(bb.list_files())

    # 2) Process (hash+metadata) concurrently
    process_files(bb, files)

    # 3) Archive (AES-256 if password provided)
    archive_path = os.path.join(out_dir, "evidence.zip")
    archive_path = arch.make_encrypted_zip(files, archive_path, password)

    # 4) Transfer (simulated copy to 'delivered/')
    delivered = comm.simulate_transfer(archive_path, deliver_dir)
    return {"archive": archive_path, "delivered": delivered, "db": db}

def main():
    ap = argparse.ArgumentParser(description="Digital Forensics Agent Pipeline (demo)")
    ap.add_argument("input", help="Input directory to scan (evidence)")
    ap.add_argument("--workdir", default="./work", help="Working directory (db, archives)")
    ap.add_argument("--password", default=None, help="AES-256 ZIP password (optional)")
    args = ap.parse_args()

    Path(args.workdir).mkdir(parents=True, exist_ok=True)
    res = run_pipeline(args.input, args.workdir, args.password)
    print(res)

if __name__ == "__main__":
    main()
