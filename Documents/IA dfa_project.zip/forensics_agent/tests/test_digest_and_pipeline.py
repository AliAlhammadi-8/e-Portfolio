import os, shutil, tempfile, json
from pathlib import Path
import hashlib

from forensics_agent.blackboard import Blackboard
from forensics_agent.agents.processing import ProcessingAgent
from forensics_agent.agents.search import SearchAgent
from forensics_agent.agents.archiving import ArchivingAgent
from forensics_agent.agents.communication import CommunicationAgent

def test_sha256_vector():
    h = hashlib.sha256(b"abc").hexdigest()
    assert h == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"

def test_end_to_end_pipeline(tmp_path):
    # Prepare temp input with a fake PDF and a small JPEG header file.
    inp = tmp_path / "evidence"
    inp.mkdir(parents=True, exist_ok=True)
    (inp / "doc.pdf").write_bytes(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n1 0 obj\n<<>>\nendobj\n")
    (inp / "image.jpg").write_bytes(b"\xFF\xD8\xFF\xE0" + b"JPEGDATA" * 10)
    (inp / "note.txt").write_text("hello world")  # 'unknown' type

    workdir = tmp_path / "work"
    os.makedirs(workdir, exist_ok=True)

    bb = Blackboard(str(workdir / "bb.db"))
    s = SearchAgent(bb)
    s.scan_directory(str(inp))
    files = list(bb.list_files())
    assert len(files) == 3

    p = ProcessingAgent(bb)
    for f in files:
        p.generate_sha256(f)
        p.extract_metadata(f)

    arch = ArchivingAgent(bb)
    archive = arch.make_encrypted_zip(files, str(workdir / "archives" / "evidence.zip"), password="test123")
    assert os.path.exists(archive)

    comm = CommunicationAgent(bb)
    delivered = comm.simulate_transfer(archive, str(workdir / "delivered"))
    assert os.path.exists(delivered)
