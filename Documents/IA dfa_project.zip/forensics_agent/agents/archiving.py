from pathlib import Path
from typing import Iterable, Optional
import pyzipper
from ..blackboard import Blackboard

class ArchivingAgent:
    def __init__(self, blackboard: Blackboard):
        self.bb = blackboard

    def make_encrypted_zip(self, files: Iterable[str], output_zip: str, password: Optional[str]) -> str:
        out = Path(output_zip)
        out.parent.mkdir(parents=True, exist_ok=True)
        with pyzipper.AESZipFile(out, 'w', compression=pyzipper.ZIP_LZMA) as zf:
            if password:
                zf.setpassword(password.encode('utf-8'))
                zf.setencryption(pyzipper.WZ_AES, nbits=256)
            count = 0
            for f in files:
                try:
                    zf.write(f, arcname=Path(f).name)
                    count += 1
                except Exception as e:
                    self.bb.log("ArchivingAgent", "WARN", f"Skip {f}: {e}")
        self.bb.create_archive_record(str(out), count, bool(password))
        self.bb.log("ArchivingAgent", "INFO", f"Created archive {out} with {count} files")
        return str(out)
