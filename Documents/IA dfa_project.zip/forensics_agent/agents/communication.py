from ..blackboard import Blackboard
import time, os

class CommunicationAgent:
    """Demo communication agent.
    Real SFTP requires Paramiko + credentials. Here we simulate transfer by copying file
    and writing a transfer record on the blackboard.
    """
    def __init__(self, blackboard: Blackboard):
        self.bb = blackboard

    def simulate_transfer(self, archive_path: str, destination_dir: str):
        try:
            os.makedirs(destination_dir, exist_ok=True)
            dest = os.path.join(destination_dir, os.path.basename(archive_path))
            # Simulate retransmission / backoff window
            time.sleep(0.1)
            with open(archive_path, 'rb') as src, open(dest, 'wb') as dst:
                dst.write(src.read())
            self.bb.put_transfer(archive_path, "SUCCESS", f"Copied to {dest}")
            self.bb.log("CommunicationAgent", "INFO", f"Delivered {archive_path} -> {dest}")
            return dest
        except Exception as e:
            self.bb.put_transfer(archive_path, "ERROR", str(e))
            self.bb.log("CommunicationAgent", "ERROR", f"Transfer failed: {e}")
            raise
