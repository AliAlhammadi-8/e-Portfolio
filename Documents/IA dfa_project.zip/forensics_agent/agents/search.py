from pathlib import Path
from typing import Iterable, Tuple
from ..blackboard import Blackboard
from ..utils.signatures import detect_type, MAX_LEN

class SearchAgent:
    def __init__(self, blackboard: Blackboard):
        self.bb = blackboard

    def scan_directory(self, directory: str) -> Iterable[Tuple[str, str]]:
        root = Path(directory)
        if not root.exists():
            self.bb.log("SearchAgent", "ERROR", f"Path not found: {directory}")
            return []
        indexed = 0
        for p in root.rglob("*"):
            if p.is_file():
                try:
                    with open(p, "rb") as f:
                        header = f.read(MAX_LEN)
                    ftype = detect_type(header) or "unknown"
                    self.bb.upsert_file(str(p), ftype)
                    indexed += 1
                except Exception as e:
                    self.bb.log("SearchAgent", "ERROR", f"Failed {p}: {e}")
        self.bb.log("SearchAgent", "INFO", f"Indexed {indexed} files under {directory}")
        return [(str(x), x) for x in self.bb.list_files()]
