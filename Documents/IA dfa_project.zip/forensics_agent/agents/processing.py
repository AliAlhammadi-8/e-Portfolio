import hashlib
from pathlib import Path
from typing import Dict, Any
from ..blackboard import Blackboard

try:
    import exifread
except Exception:
    exifread = None

try:
    from PyPDF2 import PdfReader
except Exception:
    PdfReader = None

class ProcessingAgent:
    def __init__(self, blackboard: Blackboard):
        self.bb = blackboard

    def generate_sha256(self, file_path: str, chunk_size: int = 1024*1024) -> str:
        h = hashlib.sha256()
        with open(file_path, "rb", buffering=0) as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                h.update(chunk)
        digest = h.hexdigest()
        self.bb.put_digest(file_path, "SHA-256", digest)
        return digest

    def extract_metadata(self, file_path: str) -> Dict[str, Any]:
        p = Path(file_path)
        meta: Dict[str, Any] = {"name": p.name, "size": p.stat().st_size}
        # EXIF for JPEG
        if exifread and p.suffix.lower() in (".jpg", ".jpeg"):
            try:
                with open(file_path, "rb") as f:
                    tags = exifread.process_file(f, details=False)
                lat = str(tags.get("GPS GPSLatitude", ""))
                lon = str(tags.get("GPS GPSLongitude", ""))
                meta.update({"exif_gps_lat": lat, "exif_gps_lon": lon})
            except Exception as e:
                self.bb.log("ProcessingAgent", "WARN", f"EXIF error on {file_path}: {e}")
        # PDF metadata
        if PdfReader and p.suffix.lower() == ".pdf":
            try:
                r = PdfReader(file_path)
                info = r.metadata or {}
                for k in ("/Author", "/Creator", "/Producer", "/Title", "/CreationDate"):
                    if k in info:
                        meta[k.strip("/").lower()] = str(info[k])
            except Exception as e:
                self.bb.log("ProcessingAgent", "WARN", f"PDF meta error on {file_path}: {e}")
        self.bb.put_metadata(file_path, meta)
        return meta
