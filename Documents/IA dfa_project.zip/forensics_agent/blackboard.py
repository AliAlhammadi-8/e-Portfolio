import sqlite3
import threading
from contextlib import contextmanager
from typing import Dict, Any, Iterable

class Blackboard:
    """SQLite-backed blackboard for inter-agent coordination."""
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._init()

    @contextmanager
    def _conn(self):
        with self._lock:
            con = sqlite3.connect(self.db_path)
            try:
                yield con
            finally:
                con.close()

    def _init(self):
        with self._conn() as con:
            cur = con.cursor()
            cur.execute("PRAGMA journal_mode=WAL;")
            cur.executescript("""                CREATE TABLE IF NOT EXISTS files(
                path TEXT PRIMARY KEY,
                type TEXT,
                discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS metadata(
                path TEXT,
                key TEXT,
                value TEXT,
                PRIMARY KEY(path, key)
            );
            CREATE TABLE IF NOT EXISTS digests(
                path TEXT PRIMARY KEY,
                algo TEXT,
                hexdigest TEXT
            );
            CREATE TABLE IF NOT EXISTS archives(
                archive_path TEXT PRIMARY KEY,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                file_count INTEGER,
                aes INTEGER
            );
            CREATE TABLE IF NOT EXISTS transfers(
                archive_path TEXT,
                status TEXT,
                detail TEXT,
                ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS logs(
                ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                agent TEXT,
                level TEXT,
                message TEXT
            );
            """)
            con.commit()

    # File registry
    def upsert_file(self, path: str, ftype: str):
        with self._conn() as con:
            con.execute("INSERT OR REPLACE INTO files(path,type) VALUES (?,?)", (path, ftype))
            con.commit()

    def list_files(self) -> Iterable[str]:
        with self._conn() as con:
            return [r[0] for r in con.execute("SELECT path FROM files")]

    # Metadata and digests
    def put_metadata(self, path: str, meta: Dict[str, Any]):
        with self._conn() as con:
            for k, v in meta.items():
                con.execute("INSERT OR REPLACE INTO metadata(path,key,value) VALUES (?,?,?)", (path, k, str(v)))
            con.commit()

    def put_digest(self, path: str, algo: str, hexdigest: str):
        with self._conn() as con:
            con.execute("INSERT OR REPLACE INTO digests(path,algo,hexdigest) VALUES (?,?,?)", (path, algo, hexdigest))
            con.commit()

    # Archives and transfers
    def create_archive_record(self, archive_path: str, file_count: int, aes: bool):
        with self._conn() as con:
            con.execute("INSERT OR REPLACE INTO archives(archive_path,file_count,aes) VALUES (?,?,?)",
                        (archive_path, file_count, int(aes)))
            con.commit()

    def put_transfer(self, archive_path: str, status: str, detail: str):
        with self._conn() as con:
            con.execute("INSERT INTO transfers(archive_path,status,detail) VALUES (?,?,?)",
                        (archive_path, status, detail))
            con.commit()

    # Logging
    def log(self, agent: str, level: str, message: str):
        with self._conn() as con:
            con.execute("INSERT INTO logs(agent,level,message) VALUES (?,?,?)", (agent, level, message))
            con.commit()
