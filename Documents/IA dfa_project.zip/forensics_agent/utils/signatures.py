from typing import Optional

MAGIC = {
    b"%PDF": "application/pdf",
    b"\xFF\xD8\xFF": "image/jpeg",
    b"\x89PNG\r\n\x1A\n": "image/png",
    b"PK\x03\x04": "application/zip",
}
MAX_LEN = max(len(k) for k in MAGIC.keys())

def detect_type(header: bytes) -> Optional[str]:
    for sig, mime in MAGIC.items():
        if header.startswith(sig):
            return mime
    return None
